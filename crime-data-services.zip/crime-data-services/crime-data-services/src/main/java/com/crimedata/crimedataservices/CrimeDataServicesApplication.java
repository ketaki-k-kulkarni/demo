package com.crimedata.crimedataservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrimeDataServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrimeDataServicesApplication.class, args);
	}
}

