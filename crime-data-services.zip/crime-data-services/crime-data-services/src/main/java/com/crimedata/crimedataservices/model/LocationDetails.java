package com.crimedata.crimedataservices.model;

//import javax.validation.constraints.Pattern;

/*
 * Contains Location details.
 */
public class LocationDetails {

	private double latitude;
	private double longitude;
	// @Pattern(regexp = "^[A-Z]{1,2}[0-9R][0-9A-Z]?[0-9][ABD-HJLNP-UW-Z]{2}$",
	// message = "Postcode not valid")
	private String postcode;

	public LocationDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LocationDetails(double latitude, double longitude, String postcode) {
		super();
		this.latitude = latitude;
		this.longitude = longitude;
		this.postcode = postcode;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(latitude);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(longitude);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((postcode == null) ? 0 : postcode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LocationDetails other = (LocationDetails) obj;
		if (Double.doubleToLongBits(latitude) != Double.doubleToLongBits(other.latitude))
			return false;
		if (Double.doubleToLongBits(longitude) != Double.doubleToLongBits(other.longitude))
			return false;
		if (postcode == null) {
			if (other.postcode != null)
				return false;
		} else if (!postcode.equals(other.postcode))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LocationDetails [latitude=" + latitude + ", longitude=" + longitude + ", postcode=" + postcode + "]";
	}

}
