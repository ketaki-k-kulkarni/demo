package com.crimedata.crimedataservices.controller;

import java.time.YearMonth;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.crimedata.crimedataservices.model.Crime;
import com.crimedata.crimedataservices.service.CrimeDataService;

/*
 * Handles requests and invokes services.
 */
@RestController
//@Validated
public class CrimeDataController {

	@Autowired
	private CrimeDataService crimeDataService;

	/*
	 * Retrieves crime categories.
	 */
	@GetMapping("/crime/categories")
	public ResponseEntity<List<String>> retrieveCrimeCategories() {

		List<String> categories = crimeDataService.retrieveCategories();
		if (categories == null) {
			System.out.println(HttpStatus.NOT_FOUND);
			return new ResponseEntity<>(categories, HttpStatus.NOT_FOUND);
		}
		System.out.println(HttpStatus.OK);
		return new ResponseEntity<>(categories, HttpStatus.OK);

	}

	/*
	 * Retrieves crimes details for given postcode and date.
	 */
	@GetMapping("/crimes")
	public ResponseEntity<List<Crime>> retrieveCrimesForPostcodeAndDate(@RequestParam String postcode,
			@RequestParam String date) {
		// @RequestParam(name = "date", required = false) @DateTimeFormat(pattern =
		// "yyyy-MM") YearMonth date) {

		List<Crime> crimes = crimeDataService.retrieveCrimes(postcode, date);
		if (crimes == null) {
			System.out.println(HttpStatus.NOT_FOUND);
			return new ResponseEntity<>(crimes, HttpStatus.NOT_FOUND);
		}
		System.out.println(HttpStatus.OK);
		return new ResponseEntity<>(crimes, HttpStatus.OK);
	}
}
