package com.crimedata.crimedataservices.model;

import java.util.Date;

/*
 * Contains Crime details.
 */
public class Crime {

	private String category;
	private LocationDetails location;
	private String context;
	private String outcome_status;
	private Date month;

	public Crime() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Crime(String category, String context, String outcome_status, Date month, LocationDetails location) {
		super();
		this.category = category;
		this.context = context;
		this.outcome_status = outcome_status;
		this.month = month;
		this.location = location;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getOutcome_status() {
		return outcome_status;
	}

	public void setOutcome_status(String outcome_status) {
		this.outcome_status = outcome_status;
	}

	public Date getMonth() {
		return month;
	}

	public void setMonth(Date month) {
		this.month = month;
	}

	public LocationDetails getLocation() {
		return location;
	}

	public void setLocation(LocationDetails location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Crime [category=" + category + ", location=" + location + ", context=" + context + ", outcome_status="
				+ outcome_status + ", month=" + month + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((context == null) ? 0 : context.hashCode());
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		result = prime * result + ((month == null) ? 0 : month.hashCode());
		result = prime * result + ((outcome_status == null) ? 0 : outcome_status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Crime other = (Crime) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (context == null) {
			if (other.context != null)
				return false;
		} else if (!context.equals(other.context))
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		if (month == null) {
			if (other.month != null)
				return false;
		} else if (!month.equals(other.month))
			return false;
		if (outcome_status == null) {
			if (other.outcome_status != null)
				return false;
		} else if (!outcome_status.equals(other.outcome_status))
			return false;
		return true;
	}

}
