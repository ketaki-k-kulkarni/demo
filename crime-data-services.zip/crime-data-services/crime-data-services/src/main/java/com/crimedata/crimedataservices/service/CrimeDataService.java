package com.crimedata.crimedataservices.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.crimedata.crimedataservices.model.Crime;
import com.crimedata.crimedataservices.model.LocationDetails;

@Component
public class CrimeDataService {

	private static List<String> categories = null;
	private static List<Crime> crimes = null;

	static {
		categories = new ArrayList<String>();
		categories.addAll(Arrays.asList("all-crime", "burglary", "anti-social-behaviour"));
		Crime crime = new Crime("anti-social-behaviour", "", "", new Date(),
				new LocationDetails(52.640961, -1.1126371, "TF34NT"));
		Crime crime1 = new Crime("burglary", "", "", new Date(), new LocationDetails(51.640961, -1.1667711, "TF34NT"));
		Crime crime2 = new Crime("all-crime", "", "", new Date(), new LocationDetails(51.640961, -1.1667711, "TF31AA"));
		crimes = new ArrayList<Crime>();
		crimes.add(crime);
		crimes.add(crime1);
		crimes.add(crime2);

	}

	/*
	 * Retrieves crime categories.
	 */
	public List<String> retrieveCategories() {
		return categories;
	}
	
	/*
	 * Retrieves crimes details for given postcode and date.
	 */
	public List<Crime> retrieveCrimes(String postocde, String date) { // YearMonth date) {
		if (validatePostcode(postocde) && validateDate(date)) {
			List<Crime> crimesMatched = new ArrayList<Crime>();
			for (Crime crime : crimes) {
				String existingDate = new SimpleDateFormat("yyyy-MM").format(crime.getMonth());
				if (existingDate.equals(date) && crime.getLocation() != null
						&& (postocde.equals(crime.getLocation().getPostcode()))) {
					crimesMatched.add(crime);
				}
			}
			return crimesMatched;
		}
		return null;
	}

	/*
	 * Validates postcode.
	 */
	private boolean validatePostcode(String postocde) {
		String regex = "^[A-Z]{1,2}[0-9R][0-9A-Z]?[0-9][ABD-HJLNP-UW-Z]{2}$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(postocde);
		System.out.println("Postcode validation: " + postocde + " " + matcher.matches());
		return matcher.matches();
	}

	/*
	 * Validates date.
	 */
	private boolean validateDate(String date) {// YearMonth date) {
		DateFormat sdf = new SimpleDateFormat("yyyy-MM");
		sdf.setLenient(false);
		try {
			sdf.parse(date);
			// sdf.parse(date.toString());
		} catch (ParseException e) {
			System.out.println("Date validation failed:" + date);
			return false;
		}
		System.out.println("Date validation:" + date);
		return true;
	}
}
