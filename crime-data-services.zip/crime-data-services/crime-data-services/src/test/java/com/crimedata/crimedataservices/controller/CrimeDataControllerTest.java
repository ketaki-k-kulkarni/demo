package com.crimedata.crimedataservices.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

public class CrimeDataControllerTest extends AbstractTest {
	@Override
	@Before
	public void setUp() {
		super.setUp();
	}

	@Test
	public void retrieveCrimeCategories() throws Exception {
		String uri = "/crime/categories";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		List<String> categories = super.mapFromJson(content, List.class);
		assertTrue(!categories.isEmpty());
	}

	@Test
	public void retrieveCrimesForPostcodeAndDatePostCodeInvalid() throws Exception {
		String uri = "/crimes";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).param("postcode", "TF3")
				.param("date", "2021-03").accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(404, status);
	}

	@Test
	public void retrieveCrimesForPostcodeAndDateMonthinvalid() throws Exception {
		String uri = "/crimes";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).param("postcode", "TF34NT")
				.param("date", "2021").accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(404, status);
	}

	@Test
	public void retrieveCrimes() throws Exception {

		String uri = "/crimes";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).param("postcode", "TF34NT")
				.param("date", "2021-03").accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();

		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		List<String> crimes = super.mapFromJson(content, List.class);
		assertTrue(!crimes.isEmpty());

	}

}
