package com.crimedata.crimedataservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrimeDataServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
